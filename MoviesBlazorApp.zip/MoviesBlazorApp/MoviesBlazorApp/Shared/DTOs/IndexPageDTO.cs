﻿using System;
using System.Collections.Generic;
using System.Text;
using MoviesBlazorApp.Shared.Entities;

namespace MoviesBlazorApp.Shared.DTOs
{
    public class IndexPageDTO
    {
        public List<Movie> InTheaters { get; set; }
        public List<Movie> UpcommingReleases { get; set; }
    }
}
