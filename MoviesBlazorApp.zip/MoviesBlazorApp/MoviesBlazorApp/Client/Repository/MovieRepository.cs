﻿using MoviesBlazorApp.Client.Helper;
using MoviesBlazorApp.Shared.DTOs;
using MoviesBlazorApp.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoviesBlazorApp.Client.Repository
{
    public class MovieRepository: IMovieRepository
    {
        private readonly IHttpService httpService;
        private readonly string url = "api/movies";
        public MovieRepository(IHttpService httpService)
        {
            this.httpService = httpService;
        }
        public async Task<int> CreateMovie(Movie movie)
        {
            Console.WriteLine("CreateMovie MovieRepository");
            var response = await httpService.post<Movie,int>(url, movie);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            return response.Response;
        }

        public async Task<IndexPageDTO> GetIndexPageDTO()
        {
            var response = await httpService.Get<IndexPageDTO>(url);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }

        }

        public async Task<DetailsMovieDTO> GetDetailsMovieDTO(int id)
        {
            var response = await httpService.Get<DetailsMovieDTO>($"{url}/{id}");
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }

        }
    }
}
