﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoviesBlazorApp.Shared.Entities;
using MoviesBlazorApp.Client.Helper;

namespace MoviesBlazorApp.Client.Repository
{
    public class GenreRepository : IGenreRepository
    {
        private readonly IHttpService httpService;
        private readonly string url = "api/genres";
        public GenreRepository(IHttpService httpService)
        {
            this.httpService = httpService;
        }
        public async Task<List<Genre>> GetGenre()
        {
            var response = await httpService.Get<List<Genre>>(url);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }

        }

        public async Task<Genre> GetGenre(int id)
        {
            var response = await httpService.Get<Genre>($"{url}/{id}");
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }

        }
        public async Task CreateGenre(Genre genre)
        {
            var response = await httpService.post(url, genre);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
        }

        public async Task UpdateGenre(Genre genre)
        {
            var response = await httpService.put(url, genre);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
        }

        public async Task DeleteGenre(int Id)
        {
            var response= await httpService.Delete($"{url}/{Id}");
            if(!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
        }
    }
}

