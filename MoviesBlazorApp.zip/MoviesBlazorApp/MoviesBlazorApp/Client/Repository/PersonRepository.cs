﻿using MoviesBlazorApp.Client.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoviesBlazorApp.Shared.Entities;
namespace MoviesBlazorApp.Client.Repository
{
    public class PersonRepository: IPersonRepository
    {
        private readonly IHttpService httpService;
        private readonly string url = "api/People";
        public PersonRepository(IHttpService httpService)
        {
            this.httpService = httpService;
        }

        public async Task<List<Person>> GetPerson()
        {
            var response = await httpService.Get<List<Person>>(url);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }

        }
        public async Task<Person> GetPerson(int Id)
        {
            var response = await httpService.Get<Person>($"{url}/{Id}");
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }

        }
        public async Task CreatePerson(Person person)
        {
            var response = await httpService.post(url, person);
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
        }

        public async Task<List<Person>> GetPeopleByName(string name)
        {
            var response = await httpService.Get<List<Person>>($"{url}/search/{name}");
            if (!response.Success)
            {
                throw new ApplicationException(await response.GetBody());
            }
            else
            {
                return response.Response;
            }
        }
    }
}
