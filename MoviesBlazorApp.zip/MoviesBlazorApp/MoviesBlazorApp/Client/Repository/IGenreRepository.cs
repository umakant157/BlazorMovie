﻿using MoviesBlazorApp.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoviesBlazorApp.Client.Repository
{
    public interface IGenreRepository
    {
        Task CreateGenre(Genre genre);
        Task DeleteGenre(int Id);
        Task<List<Genre>> GetGenre();
        Task<Genre> GetGenre(int id);
        Task UpdateGenre(Genre genre);
    }
}
