﻿using MoviesBlazorApp.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoviesBlazorApp.Client.Repository
{
    public interface IPersonRepository
    {
        Task CreatePerson(Person person);
        Task<List<Person>> GetPeopleByName(string name);
        Task<List<Person>> GetPerson();
        Task<Person> GetPerson(int Id);
    }
}
