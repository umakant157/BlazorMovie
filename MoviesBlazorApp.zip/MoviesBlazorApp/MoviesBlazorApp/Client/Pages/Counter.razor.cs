﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoviesBlazorApp.Client.Helper;
using MoviesBlazorApp.Shared.Entities;
using MathNet.Numerics.Statistics;

namespace MoviesBlazorApp.Client.Pages
{
    public partial class Counter
    {
        private int currentCount = 0;
        private double max = 0;
        private double min = 0;

        private void IncrementCount()
        {
            var array = new double[] { 1, 2, 3, 4, 5, 6 };
             max = array.Maximum();
             min = array.Min();

            currentCount++;
        }

        List<Movie> movies;
        protected async override Task OnInitializedAsync()
        {
            await Task.Delay(1000);
            movies = new List<Movie>()
        {
            new Movie{ Title="Spider Man-01",ReleaseDate=new DateTime() },
            new Movie{ Title="Moana-01",ReleaseDate=new DateTime() },
            new Movie{ Title="Andaz-01",ReleaseDate=new DateTime() }
        };
        }
    }
}
