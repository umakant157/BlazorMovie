using System;
using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using MoviesBlazorApp.Client.Helper;
using MoviesBlazorApp.Client.Repository;
using Microsoft.AspNetCore.Components.Authorization;
using MoviesBlazorApp.Client.Auth;

namespace MoviesBlazorApp.Client
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebAssemblyHostBuilder.CreateDefault(args);
            builder.RootComponents.Add<App>("app");

            builder.Services.AddSingleton(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });
            ConfigureServices(builder.Services);

            await builder.Build().RunAsync();
        }

        private static void ConfigureServices(IServiceCollection service)
        {
            service.AddTransient<IRepository, RepositoryInMemory>();
            service.AddScoped<IHttpService, HttpService>();
            service.AddScoped<IGenreRepository, GenreRepository>();
            service.AddScoped<IPersonRepository, PersonRepository>();
            service.AddScoped<IMovieRepository, MovieRepository>();
            service.AddScoped<IAccountRepository, AccountRepository>();

            //service.AddAuthorizationCore();

            //service.AddScoped<AuthenticationStateProvider, DummyAuthenticationStateProvider>();
            //service.AddScoped<JwtAuthenticationStateProvider>();
            //service.AddScoped<AuthenticationStateProvider, JwtAuthenticationStateProvider>(provider =>
            //        provider.GetRequiredService<JwtAuthenticationStateProvider>());
            //service.AddScoped<ILoginService, JwtAuthenticationStateProvider>(provider =>
            //        provider.GetRequiredService<JwtAuthenticationStateProvider>());

        }
    }
}
