﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text;
using System.Net.Http;

namespace MoviesBlazorApp.Client.Helper
{
    public class HttpService:IHttpService
    {
        private readonly HttpClient httpclient;

        private JsonSerializerOptions DefaultJsonSerializerOptions => new JsonSerializerOptions() { PropertyNameCaseInsensitive = true };
        public HttpService(HttpClient httpclient)
        {
            this.httpclient = httpclient;
        }

        public async Task<HttpResponseWrapper<T>> Get<T>(string Url)
        {
            var responseHttp = await httpclient.GetAsync(Url);
            if(responseHttp.IsSuccessStatusCode )
            {
                var response = await Deserialize<T>(responseHttp, DefaultJsonSerializerOptions);
                return new HttpResponseWrapper<T>(response, true, responseHttp);
            }
            else
            {
                return new HttpResponseWrapper<T>(default, false, responseHttp);
            }
        }

            public async Task<HttpResponseWrapper<object>> post<T>(string Url,T data)
        {
            var dataJson = JsonSerializer.Serialize(data);
            var stringContent = new StringContent(dataJson, Encoding.UTF8, "application/json");
            var response = await httpclient.PostAsync(Url, stringContent);

            return new HttpResponseWrapper<object>(null, response.IsSuccessStatusCode, response);
        }

        public async Task<HttpResponseWrapper<object>> put<T>(string Url, T data)
        {
            var dataJson = JsonSerializer.Serialize(data);
            var stringContent = new StringContent(dataJson, Encoding.UTF8, "application/json");
            var response = await httpclient.PutAsync(Url, stringContent);

            return new HttpResponseWrapper<object>(null, response.IsSuccessStatusCode, response);
        }
        public async Task<HttpResponseWrapper<TResponse>> post<T, TResponse>(string Url, T data)
        {
            var dataJson = JsonSerializer.Serialize(data);
            var stringContent = new StringContent(dataJson, Encoding.UTF8, "application/json");
            var response = await httpclient.PostAsync(Url, stringContent);

            if (response.IsSuccessStatusCode)
            {
                var responseDeserialize = await Deserialize<TResponse>(response, DefaultJsonSerializerOptions);
                return new HttpResponseWrapper<TResponse>(responseDeserialize, true, response);
            }
            else
            {
                return new HttpResponseWrapper<TResponse>(default, false, response);
            }
        }

        private async Task<T> Deserialize<T>(HttpResponseMessage httpResponse,JsonSerializerOptions option)
        {
            var response = await httpResponse.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<T>(response, option);
        }

        public async Task<HttpResponseWrapper<Object>> Delete(string Url)  
        {
            var responseHttp = await httpclient.DeleteAsync(Url);
            return new HttpResponseWrapper<object>(null, responseHttp.IsSuccessStatusCode, responseHttp);
           
        }
    }
}
