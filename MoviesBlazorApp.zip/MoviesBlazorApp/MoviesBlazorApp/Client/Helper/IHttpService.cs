﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoviesBlazorApp.Client.Helper
{
    public interface IHttpService
    {
        Task<HttpResponseWrapper<object>> Delete(string Url);
        Task<HttpResponseWrapper<T>> Get<T>(string Url);
        Task<HttpResponseWrapper<object>> post<T>(string Url, T data);
        Task<HttpResponseWrapper<TResponse>> post<T, TResponse>(string Url, T data);
        Task<HttpResponseWrapper<object>> put<T>(string Url, T data);
    }
}
