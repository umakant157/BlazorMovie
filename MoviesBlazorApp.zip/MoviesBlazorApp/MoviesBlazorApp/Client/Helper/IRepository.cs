﻿using MoviesBlazorApp.Shared.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MoviesBlazorApp.Client.Helper
{
    public interface IRepository
    {
        public List<Movie> GetMovies();
    }
}
