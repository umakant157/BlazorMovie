﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MoviesBlazorApp.Shared.Entities;

namespace MoviesBlazorApp.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PeopleController : ControllerBase
    {
        private readonly ApplicationDbContext applicationDbContext;

        public PeopleController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }

        [HttpPost]
        public async Task<ActionResult<int>> Post(Person person)
        {
            applicationDbContext.Add(person);
            await applicationDbContext.SaveChangesAsync();

            return person.Id;
        }

        [HttpGet]
        public async Task<ActionResult<List<Person>>> Get()
        {
            return await applicationDbContext.People.ToListAsync();
        }
        
        [HttpGet("search/{searchText}")]
        public async Task<ActionResult<List<Person>>> FilterByName(string searchText)
        {
            if (String.IsNullOrWhiteSpace(searchText)) return new List<Person>();
            return await applicationDbContext.People.Where(x=>x.Name.Contains(searchText)).Take(5).ToListAsync();


        }
    }
}
