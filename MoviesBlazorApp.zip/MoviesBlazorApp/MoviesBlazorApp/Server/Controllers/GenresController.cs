﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MoviesBlazorApp.Shared.Entities;

namespace MoviesBlazorApp.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GenresController : ControllerBase
    {
        private readonly ApplicationDbContext applicationDbContext;

        public GenresController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }

        [HttpPost]
        public async Task<ActionResult> Post(Genre genre)
        {
            applicationDbContext.Add(genre);
            await applicationDbContext.SaveChangesAsync();

            return Ok();

        }

        [HttpGet]
        public async Task<ActionResult<List<Genre>>> Get()
        {
            return await applicationDbContext.Geners.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Genre>> Get(int id)
        {
            var genre= await applicationDbContext.Geners.FirstOrDefaultAsync(x => x.Id == id);
            if (genre == null) return NotFound();
            return genre;
        }

        public async Task<ActionResult> put(Genre genre)
        {
            applicationDbContext.Attach(genre).State = EntityState.Modified;
            await applicationDbContext.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{Id}")]
        public async Task<ActionResult> delete(int Id)
        {
            var genre = await applicationDbContext.Geners.FirstOrDefaultAsync(x => x.Id == Id);
            if (genre == null)
                return NotFound();

           applicationDbContext.Remove(genre);
            await applicationDbContext.SaveChangesAsync();
            return NoContent();
        }
    }
}
