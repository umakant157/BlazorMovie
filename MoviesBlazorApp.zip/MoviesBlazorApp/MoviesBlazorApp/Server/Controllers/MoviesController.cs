﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MoviesBlazorApp.Shared.Entities;
using Microsoft.EntityFrameworkCore;
using MoviesBlazorApp.Shared.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace MoviesBlazorApp.Server.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class MoviesController : ControllerBase
    {
        private readonly ApplicationDbContext applicationDbContext;

        public MoviesController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }

        [HttpPost]
        public async Task<ActionResult<int>> Post(Movie movie)
        {
            if (movie.MoviesActors != null)
            {
                for (int i = 0; i < movie.MoviesActors.Count; i++)
                {
                    movie.MoviesActors[i].Order = i + 1;
                }
            }
            applicationDbContext.Add(movie);
            await applicationDbContext.SaveChangesAsync();

            return movie.Id;
        }
        [HttpGet]
        [Authorize(AuthenticationSchemes =JwtBearerDefaults.AuthenticationScheme)]
        public async Task<ActionResult<IndexPageDTO>> Get()
        {
            int limit = 6;

            var todaydate = DateTime.Today;
            var moviesInTheater = await applicationDbContext.Movies.Where(x => x.InTheaters).OrderByDescending(x => x.ReleaseDate).Take(limit).ToListAsync();
            var moviesUpcommingRelease = await applicationDbContext.Movies.Where(x => x.ReleaseDate > todaydate).OrderByDescending(x => x.ReleaseDate).Take(limit).ToListAsync();

            var response = new IndexPageDTO();
            response.InTheaters = moviesInTheater;
            response.UpcommingReleases = moviesUpcommingRelease;


            return response;
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<DetailsMovieDTO>> Get(int id)
        {
            var movie = await applicationDbContext.Movies.Where(x => x.Id == id)
                                          .Include(x => x.MoviesGenre).ThenInclude(x => x.Genre)
                                          .Include(x => x.MoviesActors).ThenInclude(x => x.Person)
                                          .FirstOrDefaultAsync();

            if (movie == null) return NotFound();
            movie.MoviesActors = movie.MoviesActors.OrderBy(x => x.Order).ToList();

            var model = new DetailsMovieDTO()
            {
                Movie = movie,
                Genres = movie.MoviesGenre.Select(x => x.Genre).ToList(),
                Actors = movie.MoviesActors.Select(x =>
                      new Person
                      {
                          Name = x.Person.Name,
                          Picture = x.Person.Picture,
                          Character = x.Character,
                          Id = x.PersonId
                      }).ToList()
            };

            return model;

        }

        }
    }
